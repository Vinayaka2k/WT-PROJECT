<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="new-nav.css">
	<title></title>
</head>

<style>
	body{
    margin: 0;
    padding: 0;
    background: url(image.jpg);
    background-size: cover;
    /*background-position: center;
    */font-family: sans-serif;
	}

    


    .button {
  display: inline-block;
  border-radius: 14px;
  border: 2px solid #f4511e;
  color: black;
  text-align: center;
  font-size: 28px;
  padding: 10px;
  width: 300px;
  
 
  
}



.button:hover {
 background-color:#f4511e;
  cursor: pointer;
  transition:0.7s;


}
</style>

<body>

<header>
        <h1>INFO<span>SHARE</span></h1>
        <nav>
            <ul>
                <li><a href="after-signin.php">Home</a></li>
                <li><a href="update.php">Update Info</a></li>
                <li><a href="friend.php">Add Friend</a></li>
                <li><a href="image.php">My Images</a></li>
                <li><a href="vid.php">My Videos</a></li>
                 <li><a href="index.html">LOGOUT</a></li>
                
            </ul>
        </nav>
    </header>
    
	<!--<a href="after-signin.php">HOME</a>-->
	<br><br><br>
<form method="post" action="">
    
<center><input id="go" class="button" type="submit" name="submit" value="View My Friends">
</center>
<br><br><br>
</form>

<?php
session_start();
$sess_un=$_SESSION['name'];

if(isset($_POST['submit']))
{
	
$conn=mysqli_connect("localhost","root","","data");

$sql="SELECT * FROM allusers WHERE uname='$sess_un' ";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($res);

$str=$row['friend']; 

$arr=explode(',',$str);

foreach ($arr as $i => $j)
 {

 	echo "<center><a href='frndinfo.php?friend=$j'>$j</a></center>";
 	echo "<br>";
 	echo "<br>";
 }
$conn->close();  
}

?>

</script>
</body>
</html>
