<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="new-nav.css">
  <link rel="stylesheet" type="text/css" href="videonew.css">
    <title></title>
  </head>
  <body >
    <header>
            <h1>INFO<span>SHARE</span></h1>
            <nav class="navgbar">
                <ul>
                    <li><a href="after-signin.php">HOME</a></li>
                    <li><a href="friend.php">Add Friend</a></li>
                    <li><a href="#">My Images</a></li>
                    <li><a href="#">My Videos</a></li>
                    <li><a href="view.php">View Friends</a></li>
                </ul>
            </nav>
    </header>
    <br><br>
    <div class="form">
      <form action="video.php" method='post'enctype="multipart/form-data">
      <i style="font-size:25px"> <i> <u><strong>Upload your Video :</strong></u><br>
        <input class="input" type="text" placeholder="Type some Description of Video:" name="description_entered"/><br><br>
        <input type="file" name="file"/  class="button"><br><br>

        <input type="submit" name="submit"  class="button" value="Upload"/>

    </form>
  </div>
  <body>
</html>
<?php
$conn=mysqli_connect("localhost","root","","Videos");
$sql="CREATE DATABASE Videos";
mysqli_query($conn,$sql);
$conn->close();

$conn=mysqli_connect("localhost","root","","Videos");
$sql="CREATE TABLE tablename(ID INT(11),description VARCHAR(100),finename VARCHAR(50),fileextension VARCHAR(4))";
mysqli_query($conn,$sql);

if(isset($_FILES["file"]["name"])){
$name= $_FILES["file"]["name"];

$tmp_name= $_FILES['file']['tmp_name'];

$submitbutton= $_POST['submit'];

$position= strpos($name, ".");

$fileextension= substr($name, $position + 1);

$fileextension= strtolower($fileextension);

$description= $_POST['description_entered'];

$success= -1;
}else{
    echo 'please choose file';
}

$descript= 0;

if (empty($description))
{
$descript= 1;
}

if (isset($name)) {

$path= 'Uploads/videos/';

if (!empty($name)){
if (($fileextension !== "mp4") && ($fileextension !== "ogg") && ($fileextension !== "webm"))
{
$success=0;
echo "The file extension must be .mp4, .ogg, or .webm in order to be uploaded";
}


else if (($fileextension == "mp4") || ($fileextension == "ogg") || ($fileextension == "webm"))
{
$success=1;
if (move_uploaded_file($tmp_name, $path.$name)) {
echo 'Uploaded!';
}
}
}
}
?>

<?php

//Block 1
$user = "user";
$password = "password";
$host = "host";
$dbase = "database";
$table = "tablename";



//Block 3
$connection= mysqli_connect ("localhost","root","","Videos");
if (!$connection)
{
die ('Could not connect:' . mysql_error());
}
mysqli_select_db($connection,$dbase);



//Block 4
if((!empty($description)) && ($success == 1)){
mysqli_query($connection,"INSERT INTO $table (description, filename, fileextension)
VALUES ('$description', '$name', '$fileextension')");
}


//Block 5
mysqli_close($connection);

?>
<p id="para6">


<?php
$user = "user";
$password = "password";
$host = "host";
$dbase = "database";
$table = "tablename";

// Connection to DBase
$connection = mysqli_connect("localhost","root","","Videos");
@mysqli_select_db($connection,"Videos") or die("Unable to select database");
$s = "SELECT description, filename, fileextension FROM $table ORDER BY ID DESC LIMIT 50";
$result= mysqli_query( $connection,$s );
/*or die("SELECT Error: ".mysqli_error($connection)*/

print "<table  class=\"table\" align=\"center\">\n";
print"<tr>";
print"<td style=\"text-align:center\"><strong style=\"color:blue\" ><u> Description</u> </strong></td>";
print "<td style=\"text-align:center\"><strong style=\"color:blue\" ><u> Video </u></strong></td>";
print"</tr>";
//echo "$result";
while ($row = mysqli_fetch_assoc($result))
{
$videos_field= $row['filename'];
$video_show= "Uploads/videos/$videos_field";
$descriptionvalue= $row['description'];
$fileextensionvalue= $row['fileextension'];
print "<tr>\n";
print "\t<td style=\"color:white;text-align:center\" >\n";
echo "<font face=arial size=5/>$descriptionvalue</font>";
print "</td >\n";
print "\t<td >\n";
echo "<div align=center><video width='320' controls><source src='$video_show' type='video/$fileextensionvalue'>Your browser does
not support the video tag.</video></div>";
print "</td >\n";
print "</tr >\n";
}
print "</table>\n";

$conn->close();

?>
