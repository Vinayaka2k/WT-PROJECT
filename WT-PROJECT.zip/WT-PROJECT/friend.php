<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="new-nav.css">
	<title></title>
<style>
	body{
    margin: 0;
    padding: 0;
    background: url(image.jpg);
    background-size: cover;
    /*background-position: center;
    */font-family: sans-serif;
	}

	#add_friend{

		/*padding-left: 520px;
		*/font-family: sans-serif;
		color:#f0fcd0;
		font-size:35px;

		
	}
	
	.input1{
		text-align: center;
		font-size: 20px;
		/*margin-left:400px;
		*/font-family: sans-serif;
		border:3px solid white;
	 height: 50px;
    border-radius: 25px;
    display: inline-block;
    width: 500px;
    background: #e6e6e6;
   font-family: sans-serif;
    
	color: #666666;
	
	
	}

.input1:focus {
	border-color: red;
	transition: 0.5s;
	
	}
input {
    outline: none;
    border: none;
}
	.button {
  
  border-radius: 14px;
  border: 2px solid #f4511e;
  color: black;
  text-align: center;
  font-size: 28px;
  width:200px;
  height:50px;
  
 
  /*margin-left: 520px;
*/
}



.button:hover {
 background-color:#f4511e;
  cursor: pointer;
  transition:0.7s;


}
#d{
	text-align: center;
}
#d1{
	display: inline-block;
}

	</style>
</head>
<body>
	<header>
        <h1>INFO<span>SHARE</span></h1>
        <nav>
            <ul>
				<li><a href="after-signin.php">Home</a></li>
                <li><a href="update.php">Update Info</a></li>
                
                <li><a href="image.php">My Images</a></li>
                <li><a href="vid.php">My Videos</a></li>
                <li><a href="view.php">View Friends</a></li>
                 <li><a href="index.html">LOGOUT</a></li>
            </ul>
        </nav><br><br><br>
<form method="post" action="">
		<br><br><br>
		<div id="d">
	<div id="d1">	
	<h4 id="add_friend">Add Friend </h4>
	<input size="25" class="input1" type="text" name="fnd" placeholder="Enter the user name of your friend">
	<br><br>
<br><br>
	<input type="submit" class="button" name="submit" value="GO!" style="vertical-align:middle">
	</div></div>
</form>

<?php
extract($_POST);
$flag=0;
$arr1=array();
session_start();
$sess_un=$_SESSION['name'];
if(isset($_POST['submit']))
{
$conn=mysqli_connect("localhost","root","","data");

// to check a valid friend ///

$sql="SELECT * FROM allusers";
$res=mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($res))
{		
	array_push($arr1,$row['uname']);
}

if(in_array($fnd,$arr1))
	$flag=1;
else
	$flag=0;

/////       /////////

if($flag)
{
$sql="SELECT * FROM allusers WHERE uname='$sess_un' ";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($res);

if($row['friend'] == NULL)
	$str=$fnd;
else
	$str=$row['friend'].','.$fnd;


$sql="UPDATE allusers SET friend='$str' WHERE uname='$sess_un' ";
mysqli_query($conn,$sql);
echo "<script>alert('Friend has been added successfully!');
window.location='after-signin.php';
</script>";

}
else

echo "<script>
	alert('The entered User has not yet registered');
	
</script>";

$conn->close();  
}

?>
</body>
</html>
